This release version does not include FOTA test capabilities.

UUID of mfw-pti_nrf91x1_2.3.3 is 2cfe8d85-0156-4123-8c53-76f007a6c9ca